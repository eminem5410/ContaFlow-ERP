using ContaFlow.Domain.Events;

namespace ContaFlow.Infrastructure.Messaging;

/// <summary>
/// Interfaz para publicar eventos de dominio en Kafka.
/// </summary>
public interface IKafkaProducer
{
    /// <summary>
    /// Publica un evento de dominio tipado al topic correspondiente según su EventType.
    /// </summary>
    Task PublishAsync<TEvent>(TEvent domainEvent, CancellationToken cancellationToken = default)
        where TEvent : DomainEvent;

    /// <summary>
    /// Publica un mensaje serializado (JSON) a un topic específico.
    /// </summary>
    Task PublishAsync(string topic, string message, CancellationToken cancellationToken = default);
}
