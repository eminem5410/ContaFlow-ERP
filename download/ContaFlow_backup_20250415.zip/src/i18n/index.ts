import { useCallback, useMemo } from 'react'
import { useAppStore } from '@/lib/store'

export type Locale = 'es' | 'pt' | 'en'

export const LOCALES: { code: Locale; label: string; flag: string }[] = [
  { code: 'es', label: 'Espanol', flag: 'AR' },
  { code: 'pt', label: 'Portugues', flag: 'BR' },
  { code: 'en', label: 'English', flag: 'US' },
]

export const DEFAULT_LOCALE: Locale = 'es'

const LOCALE_LABELS: Record<Locale, string> = {
  es: 'Espanol',
  pt: 'Portugues',
  en: 'English',
}

// Nested key accessor: "accounts.title" → translations.accounts.title
function getNestedValue(obj: Record<string, unknown>, path: string): string {
  const keys = path.split('.')
  let current: unknown = obj
  for (const key of keys) {
    if (current && typeof current === 'object' && key in (current as Record<string, unknown>)) {
      current = (current as Record<string, unknown>)[key]
    } else {
      return path // fallback: return the key itself
    }
  }
  return typeof current === 'string' ? current : path
}

// Cache for loaded locale data
let localeCache: Record<Locale, Record<string, unknown>> | null = null

async function loadLocaleData(locale: Locale): Promise<Record<string, unknown>> {
  if (localeCache?.[locale]) return localeCache[locale]

  let data: Record<string, unknown>
  switch (locale) {
    case 'es':
      data = (await import('./locales/es.json')).default
      break
    case 'pt':
      data = (await import('./locales/pt.json')).default
      break
    case 'en':
      data = (await import('./locales/en.json')).default
      break
    default:
      data = (await import('./locales/es.json')).default
  }

  if (!localeCache) localeCache = {} as Record<Locale, Record<string, unknown>>
  localeCache[locale] = data
  return data
}

// Preload default locale synchronously (only ES, since it's the default)
// For client-side: we load the locale in the hook
let esData: Record<string, unknown> | null = null
try {
  esData = require('./locales/es.json').default
} catch {
  // Will be loaded async
}

/**
 * Custom i18n hook for ContaFlow.
 * Uses Zustand store to persist locale preference.
 * Returns a `t` function and helpers.
 *
 * Usage:
 *   const { t, locale, setLocale, formatDate } = useTranslation()
 *   <h1>{t('accounts.title')}</h1>
 *   <p>{t('common.save')}</p>
 */
export function useTranslation() {
  const locale = (useAppStore((s) => s.locale) || DEFAULT_LOCALE) as Locale
  const setLocaleStore = useAppStore((s) => s.setLocale)

  // Use cached locale data or fallback
  const translations = useMemo(() => {
    if (locale === 'es' && esData) return esData
    if (localeCache?.[locale]) return localeCache[locale]
    // If not cached yet, return ES as fallback (it will re-render once loaded)
    return esData || ({} as Record<string, unknown>)
  }, [locale])

  // Trigger async load if needed
  useMemo(() => {
    if (!localeCache?.[locale]) {
      loadLocaleData(locale).catch(() => {
        // Silent fail, already using fallback
      })
    }
  }, [locale])

  const t = useCallback(
    (key: string, vars?: Record<string, string | number>): string => {
      let value = getNestedValue(translations as Record<string, unknown>, key)

      // Replace variables: {{count}} → actual value
      if (vars) {
        for (const [k, v] of Object.entries(vars)) {
          value = value.replace(new RegExp(`\\{\\{${k}\\}\\}`, 'g'), String(v))
        }
      }

      return value
    },
    [translations],
  )

  const setLocale = useCallback(
    (newLocale: Locale) => {
      // Load the locale data async (will be cached for next render)
      loadLocaleData(newLocale).catch(() => {})
      setLocaleStore(newLocale)
    },
    [setLocaleStore],
  )

  const getLocaleLabel = useCallback(
    (loc?: Locale) => LOCALE_LABELS[loc || locale],
    [locale],
  )

  return {
    t,
    locale,
    setLocale,
    getLocaleLabel,
    /** Format a number as ARS currency */
    formatCurrency: (amount: number) =>
      new Intl.NumberFormat(locale === 'en' ? 'en-US' : locale === 'pt' ? 'pt-BR' : 'es-AR', {
        style: 'currency',
        currency: 'ARS',
        minimumFractionDigits: 2,
      }).format(amount),
    /** Format a date string */
    formatDate: (dateStr: string) =>
      new Intl.DateTimeFormat(locale === 'en' ? 'en-US' : locale === 'pt' ? 'pt-BR' : 'es-AR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
      }).format(new Date(dateStr)),
  }
}

export type TranslationHook = ReturnType<typeof useTranslation>
