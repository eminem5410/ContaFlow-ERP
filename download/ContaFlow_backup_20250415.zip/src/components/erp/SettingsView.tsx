'use client'

import { useState } from 'react'
import { useQuery, useMutation } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Settings, Building2, Save, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { useAppStore } from '@/lib/store'
import { api } from '@/lib/api'

interface CompanyData {
  id: string
  name: string
  cuit: string | null
  email: string | null
  phone: string | null
  address: string | null
  plan: string
  logo: string | null
}

export function SettingsView() {
  const companyId = useAppStore((s) => s.user?.companyId)

  const { data, isLoading } = useQuery<{ company: CompanyData }>({
    queryKey: ['settings', companyId],
    queryFn: () => api.get('/api/settings', { companyId: companyId! }),
    enabled: !!companyId,
  })

  const company = data?.company

  const defaultForm = {
    name: '',
    cuit: '',
    email: '',
    phone: '',
    address: '',
  }

  const [prevCompany, setPrevCompany] = useState<CompanyData | null>(null)
  const [form, setForm] = useState(defaultForm)

  // Sync form when company data loads (React pattern: setState during render)
  if (company && company !== prevCompany) {
    setPrevCompany(company)
    setForm({
      name: company.name || '',
      cuit: company.cuit || '',
      email: company.email || '',
      phone: company.phone || '',
      address: company.address || '',
    })
  }

  const saveMutation = useMutation({
    mutationFn: (data: typeof form) => api.put('/api/settings', { ...data, companyId }),
    onSuccess: () => {
      toast.success('Configuración guardada exitosamente')
    },
    onError: (error: Error) => toast.error('Error', { description: error.message }),
  })

  const handleSave = () => {
    if (!form.name.trim()) {
      toast.error('El nombre de la empresa es obligatorio')
      return
    }
    saveMutation.mutate(form)
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-64" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-48" />
              <Skeleton className="h-4 w-64" />
            </CardHeader>
            <CardContent className="space-y-4">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="space-y-2">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-9 w-full" />
                </div>
              ))}
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-48" />
              <Skeleton className="h-4 w-64" />
            </CardHeader>
            <CardContent className="space-y-4">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="space-y-2">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-9 w-full" />
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-100">
            <Settings className="h-5 w-5 text-slate-600" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-slate-900">Configuración General</h2>
            <p className="text-sm text-slate-500">Administrá los datos de tu empresa</p>
          </div>
        </div>
        <Button
          onClick={handleSave}
          className="bg-emerald-600 hover:bg-emerald-700 text-white"
          disabled={saveMutation.isPending}
        >
          {saveMutation.isPending ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Guardando...
            </>
          ) : (
            <>
              <Save className="mr-2 h-4 w-4" />
              Guardar Cambios
            </>
          )}
        </Button>
      </div>

      {/* Plan Badge */}
      {company?.plan && (
        <Card className="border-emerald-200 bg-emerald-50/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Building2 className="h-5 w-5 text-emerald-600" />
                <span className="text-sm font-medium text-slate-700">Plan Actual</span>
              </div>
              <span className="text-sm font-semibold text-emerald-700 capitalize">{company.plan}</span>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Datos de la Empresa */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Building2 className="h-4.5 w-4.5 text-slate-500" />
              Datos de la Empresa
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Nombre / Razón Social *</Label>
              <Input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Nombre de la empresa"
              />
            </div>
            <div className="space-y-2">
              <Label>CUIT</Label>
              <Input
                value={form.cuit}
                onChange={(e) => setForm({ ...form, cuit: e.target.value })}
                placeholder="30-12345678-9"
              />
            </div>
            <div className="space-y-2">
              <Label>Dirección</Label>
              <Input
                value={form.address}
                onChange={(e) => setForm({ ...form, address: e.target.value })}
                placeholder="Av. Corrientes 1234, CABA"
              />
            </div>
          </CardContent>
        </Card>

        {/* Información de Contacto */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Settings className="h-4.5 w-4.5 text-slate-500" />
              Información de Contacto
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Email</Label>
              <Input
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="empresa@email.com"
              />
            </div>
            <div className="space-y-2">
              <Label>Teléfono</Label>
              <Input
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                placeholder="+54 11 1234-5678"
              />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
