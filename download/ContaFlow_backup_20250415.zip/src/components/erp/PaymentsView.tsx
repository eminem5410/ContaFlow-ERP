'use client'

import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { Plus, Pencil, Trash2, Search, ArrowDownCircle, ArrowUpCircle, FileDown } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useAppStore } from '@/lib/store'
import { api } from '@/lib/api'
import { usePermission } from '@/hooks/use-permission'
import { exportPaymentsToExcel } from '@/lib/export-excel'
import { formatCurrency, formatDate } from '@/lib/formatters'

interface Payment {
  id: string
  number: string
  date: string
  amount: number
  method: string
  reference: string | null
  type: string
  notes: string | null
  invoiceId: string | null
  clientId: string | null
  providerId: string | null
  bankAccountId: string | null
  client?: { id: string; name: string } | null
  provider?: { id: string; name: string } | null
  invoice?: { id: string; number: string } | null
  bankAccount?: { id: string; name: string } | null
}

interface ClientOption {
  id: string
  name: string
}

interface ProviderOption {
  id: string
  name: string
}

interface InvoiceOption {
  id: string
  number: string
  clientId?: string | null
  providerId?: string | null
}

interface BankAccountOption {
  id: string
  name: string
}

const emptyForm = {
  type: 'cobro' as string,
  date: new Date().toISOString().split('T')[0],
  amount: '',
  method: '',
  reference: '',
  notes: '',
  clientId: '',
  providerId: '',
  invoiceId: '',
  bankAccountId: '',
}

const typeBadge: Record<string, { label: string; className: string }> = {
  cobro: { label: 'Cobro', className: 'bg-emerald-100 text-emerald-700 hover:bg-emerald-100' },
  pago: { label: 'Pago', className: 'bg-red-100 text-red-700 hover:bg-red-100' },
}

const methodBadge: Record<string, { label: string; className: string }> = {
  efectivo: { label: 'Efectivo', className: 'bg-yellow-100 text-yellow-700 hover:bg-yellow-100' },
  transferencia: { label: 'Transferencia', className: 'bg-blue-100 text-blue-700 hover:bg-blue-100' },
  cheque: { label: 'Cheque', className: 'bg-orange-100 text-orange-700 hover:bg-orange-100' },
  tarjeta: { label: 'Tarjeta', className: 'bg-purple-100 text-purple-700 hover:bg-purple-100' },
}

export function PaymentsView() {
  const companyId = useAppStore((s) => s.user?.companyId)
  const { canCreate, canEdit, canDelete, canExport } = usePermission()
  const queryClient = useQueryClient()
  const [search, setSearch] = useState('')
  const [typeFilter, setTypeFilter] = useState<string>('')
  const [methodFilter, setMethodFilter] = useState<string>('')
  const [showDialog, setShowDialog] = useState(false)
  const [editingPayment, setEditingPayment] = useState<Payment | null>(null)
  const [deletingPayment, setDeletingPayment] = useState<Payment | null>(null)
  const [form, setForm] = useState(emptyForm)

  // Main payments query
  const { data, isLoading } = useQuery<{ payments: Payment[]; pagination: { total: number } }>({
    queryKey: ['payments', companyId, search, typeFilter, methodFilter],
    queryFn: () => api.get('/api/payments', { companyId: companyId!, search: search || undefined, type: typeFilter || undefined, method: methodFilter || undefined }),
    enabled: !!companyId,
  })

  // Related entities for the dialog (only loaded when dialog is open)
  const { data: clientsData } = useQuery<{ clients: ClientOption[] }>({
    queryKey: ['clients-list', companyId],
    queryFn: () => api.get('/api/clients', { companyId: companyId!, limit: 100 }),
    enabled: !!companyId && showDialog,
  })

  const { data: providersData } = useQuery<{ providers: ProviderOption[] }>({
    queryKey: ['providers-list', companyId],
    queryFn: () => api.get('/api/providers', { companyId: companyId!, limit: 100 }),
    enabled: !!companyId && showDialog,
  })

  const { data: invoicesData } = useQuery<{ invoices: InvoiceOption[] }>({
    queryKey: ['invoices-list', companyId],
    queryFn: () => api.get('/api/invoices', { companyId: companyId!, limit: 100 }),
    enabled: !!companyId && showDialog,
  })

  const { data: bankAccountsData } = useQuery<{ bankAccounts: BankAccountOption[] }>({
    queryKey: ['bank-accounts-list', companyId],
    queryFn: () => api.get('/api/bank-accounts', { companyId: companyId!, limit: 50 }),
    enabled: !!companyId && showDialog,
  })

  // Filter invoices based on selected client or provider
  const filteredInvoices = invoicesData?.invoices?.filter((inv) => {
    if (form.type === 'cobro' && form.clientId) {
      return inv.clientId === form.clientId
    }
    if (form.type === 'pago' && form.providerId) {
      return inv.providerId === form.providerId
    }
    return true
  })

  const createMutation = useMutation({
    mutationFn: (data: typeof emptyForm) => api.post('/api/payments', {
        amount: parseFloat(data.amount) || 0,
        method: data.method,
        reference: data.reference || null,
        type: data.type,
        notes: data.notes || null,
        invoiceId: data.invoiceId || null,
        clientId: data.type === 'cobro' ? (data.clientId || null) : null,
        providerId: data.type === 'pago' ? (data.providerId || null) : null,
        bankAccountId: data.bankAccountId || null,
        companyId,
        date: data.date,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['payments'] })
      toast.success('Pago/cobro creado exitosamente')
      closeDialog()
    },
    onError: (error: Error) => toast.error('Error', { description: error.message }),
  })

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: typeof emptyForm }) => api.put(`/api/payments/${id}`, {
        date: data.date,
        amount: parseFloat(data.amount) || 0,
        method: data.method,
        reference: data.reference || null,
        type: data.type,
        notes: data.notes || null,
        invoiceId: data.invoiceId || null,
        clientId: data.type === 'cobro' ? (data.clientId || null) : null,
        providerId: data.type === 'pago' ? (data.providerId || null) : null,
        bankAccountId: data.bankAccountId || null,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['payments'] })
      toast.success('Pago/cobro actualizado exitosamente')
      closeDialog()
    },
    onError: (error: Error) => toast.error('Error', { description: error.message }),
  })

  const deleteMutation = useMutation({
    mutationFn: (id: string) => api.del(`/api/payments/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['payments'] })
      toast.success('Pago/cobro eliminado')
      setDeletingPayment(null)
    },
    onError: (error: Error) => toast.error('Error', { description: error.message }),
  })

  const resetForm = () => {
    setForm({
      ...emptyForm,
      date: new Date().toISOString().split('T')[0],
    })
  }
  const closeDialog = () => { setShowDialog(false); setEditingPayment(null); resetForm() }

  const openCreate = () => { resetForm(); setShowDialog(true) }

  const openEdit = (payment: Payment) => {
    setEditingPayment(payment)
    setForm({
      type: payment.type,
      date: payment.date ? payment.date.split('T')[0] : '',
      amount: String(payment.amount),
      method: payment.method,
      reference: payment.reference || '',
      notes: payment.notes || '',
      clientId: payment.clientId || '',
      providerId: payment.providerId || '',
      invoiceId: payment.invoiceId || '',
      bankAccountId: payment.bankAccountId || '',
    })
    setShowDialog(true)
  }

  const handleTypeChange = (newType: string) => {
    setForm({
      ...form,
      type: newType,
      clientId: '',
      providerId: '',
      invoiceId: '',
    })
  }

  const handleSave = () => {
    if (!form.type) {
      toast.error('El tipo es obligatorio')
      return
    }
    if (!form.amount || parseFloat(form.amount) <= 0) {
      toast.error('El monto debe ser mayor a 0')
      return
    }
    if (!form.method) {
      toast.error('El método de pago es obligatorio')
      return
    }
    if (!form.date) {
      toast.error('La fecha es obligatoria')
      return
    }
    if (editingPayment) {
      updateMutation.mutate({ id: editingPayment.id, data: form })
    } else {
      createMutation.mutate(form)
    }
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="flex-1 w-full sm:max-w-sm">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <Input
              placeholder="Buscar por cliente, proveedor o referencia..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {canExport('payments') && data?.payments && (
            <Button
              variant="outline"
              onClick={() => exportPaymentsToExcel(
                data.payments.map(p => ({
                  date: p.date,
                  type: p.type,
                  amount: p.amount,
                  method: p.method,
                  reference: p.reference,
                  status: '',
                }))
              )}
              disabled={data.payments.length === 0}
            >
              <FileDown className="mr-2 h-4 w-4" />
              Exportar Excel
            </Button>
          )}
          {canCreate('payments') && (
            <Button onClick={openCreate} className="bg-emerald-600 hover:bg-emerald-700 text-white">
              <Plus className="mr-2 h-4 w-4" />
              Nuevo Pago/Cobro
            </Button>
          )}
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <Select value={typeFilter} onValueChange={(v) => setTypeFilter(v === 'all' ? '' : v)}>
          <SelectTrigger className="w-full sm:w-[180px]">
            <SelectValue placeholder="Tipo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos los tipos</SelectItem>
            <SelectItem value="cobro">Cobro</SelectItem>
            <SelectItem value="pago">Pago</SelectItem>
          </SelectContent>
        </Select>
        <Select value={methodFilter} onValueChange={(v) => setMethodFilter(v === 'all' ? '' : v)}>
          <SelectTrigger className="w-full sm:w-[200px]">
            <SelectValue placeholder="Método" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos los métodos</SelectItem>
            <SelectItem value="efectivo">Efectivo</SelectItem>
            <SelectItem value="transferencia">Transferencia</SelectItem>
            <SelectItem value="cheque">Cheque</SelectItem>
            <SelectItem value="tarjeta">Tarjeta</SelectItem>
          </SelectContent>
        </Select>
        {(typeFilter || methodFilter) && (
          <Button
            variant="ghost"
            size="sm"
            className="text-slate-500 hover:text-slate-700"
            onClick={() => { setTypeFilter(''); setMethodFilter('') }}
          >
            Limpiar filtros
          </Button>
        )}
      </div>

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[1000px]">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50">
                  <th className="text-left px-4 py-2.5 text-xs font-medium text-slate-500 uppercase tracking-wider">Nro</th>
                  <th className="text-left px-4 py-2.5 text-xs font-medium text-slate-500 uppercase tracking-wider">Tipo</th>
                  <th className="text-left px-4 py-2.5 text-xs font-medium text-slate-500 uppercase tracking-wider">Fecha</th>
                  <th className="text-left px-4 py-2.5 text-xs font-medium text-slate-500 uppercase tracking-wider">Cliente/Proveedor</th>
                  <th className="text-left px-4 py-2.5 text-xs font-medium text-slate-500 uppercase tracking-wider">Factura</th>
                  <th className="text-left px-4 py-2.5 text-xs font-medium text-slate-500 uppercase tracking-wider">Método</th>
                  <th className="text-left px-4 py-2.5 text-xs font-medium text-slate-500 uppercase tracking-wider">Referencia</th>
                  <th className="text-right px-4 py-2.5 text-xs font-medium text-slate-500 uppercase tracking-wider">Monto</th>
                  <th className="text-center px-4 py-2.5 text-xs font-medium text-slate-500 uppercase tracking-wider w-24">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <tr key={i} className="border-b border-slate-100">
                      {Array.from({ length: 9 }).map((_, j) => (
                        <td key={j} className="px-4 py-3"><Skeleton className="h-4 w-full" /></td>
                      ))}
                    </tr>
                  ))
                ) : data?.payments?.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="text-center py-12 text-slate-400 text-sm">
                      No se encontraron pagos/cobros
                    </td>
                  </tr>
                ) : (
                  data?.payments?.map((payment) => {
                    const tBadge = typeBadge[payment.type]
                    const mBadge = methodBadge[payment.method]
                    return (
                      <tr key={payment.id} className="border-b border-slate-100 hover:bg-slate-50 transition-colors group">
                        <td className="px-4 py-3 text-sm font-mono text-slate-500">{payment.number}</td>
                        <td className="px-4 py-3 text-sm">
                          {tBadge ? (
                            <Badge variant="secondary" className={tBadge.className}>
                              <span className="flex items-center gap-1">
                                {payment.type === 'cobro' ? <ArrowDownCircle className="h-3 w-3" /> : <ArrowUpCircle className="h-3 w-3" />}
                                {tBadge.label}
                              </span>
                            </Badge>
                          ) : (
                            <span className="text-slate-500 capitalize">{payment.type}</span>
                          )}
                        </td>
                        <td className="px-4 py-3 text-sm text-slate-600">{payment.date ? formatDate(payment.date) : '-'}</td>
                        <td className="px-4 py-3 text-sm font-medium text-slate-800">
                          {payment.client?.name || payment.provider?.name || '-'}
                        </td>
                        <td className="px-4 py-3 text-sm text-slate-600">{payment.invoice?.number || '-'}</td>
                        <td className="px-4 py-3 text-sm">
                          {mBadge ? (
                            <Badge variant="secondary" className={mBadge.className}>
                              {mBadge.label}
                            </Badge>
                          ) : (
                            <span className="text-slate-500 capitalize">{payment.method}</span>
                          )}
                        </td>
                        <td className="px-4 py-3 text-sm font-mono text-slate-600">{payment.reference || '-'}</td>
                        <td className="px-4 py-3 text-sm text-right font-mono font-medium text-slate-700">
                          {payment.type === 'cobro' ? (
                            <span className="text-emerald-600">+{formatCurrency(payment.amount)}</span>
                          ) : (
                            <span className="text-red-600">-{formatCurrency(payment.amount)}</span>
                          )}
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center justify-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            {canEdit('payments') && (
                              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(payment)}>
                                <Pencil className="h-3.5 w-3.5" />
                              </Button>
                            )}
                            {canDelete('payments') && (
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-7 w-7 text-red-500 hover:text-red-700 hover:bg-red-50"
                                onClick={() => setDeletingPayment(payment)}
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    )
                  })
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Create/Edit Dialog */}
      <Dialog open={showDialog} onOpenChange={(open) => !open && closeDialog()}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingPayment ? 'Editar Pago/Cobro' : 'Nuevo Pago/Cobro'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            {/* Type */}
            <div className="space-y-2">
              <Label>Tipo *</Label>
              <div className="grid grid-cols-2 gap-3">
                <Button
                  type="button"
                  variant={form.type === 'cobro' ? 'default' : 'outline'}
                  className={
                    form.type === 'cobro'
                      ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                      : 'border-emerald-200 text-emerald-700 hover:bg-emerald-50'
                  }
                  onClick={() => handleTypeChange('cobro')}
                >
                  <ArrowDownCircle className="mr-2 h-4 w-4" />
                  Cobro
                </Button>
                <Button
                  type="button"
                  variant={form.type === 'pago' ? 'default' : 'outline'}
                  className={
                    form.type === 'pago'
                      ? 'bg-red-600 hover:bg-red-700 text-white'
                      : 'border-red-200 text-red-700 hover:bg-red-50'
                  }
                  onClick={() => handleTypeChange('pago')}
                >
                  <ArrowUpCircle className="mr-2 h-4 w-4" />
                  Pago
                </Button>
              </div>
            </div>

            {/* Date & Amount */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Fecha *</Label>
                <Input
                  type="date"
                  value={form.date}
                  onChange={(e) => setForm({ ...form, date: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Monto *</Label>
                <Input
                  type="number"
                  step="0.01"
                  min="0"
                  value={form.amount}
                  onChange={(e) => setForm({ ...form, amount: e.target.value })}
                  placeholder="0.00"
                />
              </div>
            </div>

            {/* Method & Reference */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Método *</Label>
                <Select value={form.method} onValueChange={(v) => setForm({ ...form, method: v })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar método" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="efectivo">Efectivo</SelectItem>
                    <SelectItem value="transferencia">Transferencia</SelectItem>
                    <SelectItem value="cheque">Cheque</SelectItem>
                    <SelectItem value="tarjeta">Tarjeta</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Referencia</Label>
                <Input
                  value={form.reference}
                  onChange={(e) => setForm({ ...form, reference: e.target.value })}
                  placeholder="Nro de comprobante..."
                />
              </div>
            </div>

            {/* Client/Provider select */}
            {form.type === 'cobro' && (
              <div className="space-y-2">
                <Label>Cliente</Label>
                <Select value={form.clientId} onValueChange={(v) => setForm({ ...form, clientId: v, invoiceId: '' })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar cliente" />
                  </SelectTrigger>
                  <SelectContent>
                    {clientsData?.clients?.map((client) => (
                      <SelectItem key={client.id} value={client.id}>{client.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            {form.type === 'pago' && (
              <div className="space-y-2">
                <Label>Proveedor</Label>
                <Select value={form.providerId} onValueChange={(v) => setForm({ ...form, providerId: v, invoiceId: '' })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar proveedor" />
                  </SelectTrigger>
                  <SelectContent>
                    {providersData?.providers?.map((provider) => (
                      <SelectItem key={provider.id} value={provider.id}>{provider.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* Invoice select (filtered by selected client/provider) */}
            <div className="space-y-2">
              <Label>Factura (opcional)</Label>
              <Select value={form.invoiceId} onValueChange={(v) => setForm({ ...form, invoiceId: v })}>
                <SelectTrigger>
                  <SelectValue placeholder={
                    (form.type === 'cobro' && !form.clientId) || (form.type === 'pago' && !form.providerId)
                      ? 'Seleccione primero cliente/proveedor'
                      : 'Seleccionar factura'
                  } />
                </SelectTrigger>
                <SelectContent>
                  {filteredInvoices?.map((inv) => (
                    <SelectItem key={inv.id} value={inv.id}>{inv.number}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Bank Account */}
            <div className="space-y-2">
              <Label>Cuenta Bancaria</Label>
              <Select value={form.bankAccountId} onValueChange={(v) => setForm({ ...form, bankAccountId: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="Seleccionar cuenta bancaria" />
                </SelectTrigger>
                <SelectContent>
                  {bankAccountsData?.bankAccounts?.map((account) => (
                    <SelectItem key={account.id} value={account.id}>{account.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Notes */}
            <div className="space-y-2">
              <Label>Notas</Label>
              <Input
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
                placeholder="Notas adicionales..."
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={closeDialog}>Cancelar</Button>
            <Button
              onClick={handleSave}
              className={
                form.type === 'cobro'
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                  : 'bg-red-600 hover:bg-red-700 text-white'
              }
              disabled={createMutation.isPending || updateMutation.isPending}
            >
              {(createMutation.isPending || updateMutation.isPending) ? 'Guardando...' : 'Guardar'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deletingPayment} onOpenChange={(open) => !open && setDeletingPayment(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar {deletingPayment?.type === 'cobro' ? 'cobro' : 'pago'}?</AlertDialogTitle>
            <AlertDialogDescription>
              Se eliminará el {deletingPayment?.type === 'cobro' ? 'cobro' : 'pago'}{' '}
              <strong>{deletingPayment?.number}</strong> por{' '}
              <strong>{deletingPayment ? formatCurrency(deletingPayment.amount) : ''}</strong>.
              Esta acción no se puede deshacer.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={() => deletingPayment && deleteMutation.mutate(deletingPayment.id)} className="bg-red-600 hover:bg-red-700">
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
