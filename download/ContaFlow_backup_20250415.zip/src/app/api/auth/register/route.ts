import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { hashPassword, generateAccessToken, generateRefreshToken } from '@/lib/auth'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, password, name, companyName, cuit } = body

    if (!email || !password || !name || !companyName) {
      return NextResponse.json(
        { error: 'Email, password, name, and companyName are required' },
        { status: 400 }
      )
    }

    // Check if user email already exists
    const existingUser = await db.user.findUnique({
      where: { email },
    })

    if (existingUser) {
      return NextResponse.json(
        { error: 'Email already registered' },
        { status: 409 }
      )
    }

    // Check if CUIT already exists
    if (cuit) {
      const existingCompany = await db.company.findUnique({
        where: { cuit },
      })

      if (existingCompany) {
        return NextResponse.json(
          { error: 'CUIT already registered' },
          { status: 409 }
        )
      }
    }

    // Hash the password
    const hashedPassword = await hashPassword(password)

    // Create company
    const company = await db.company.create({
      data: {
        name: companyName,
        cuit: cuit || null,
      },
    })

    // Create default "Administrador" role for the new company
    const adminRole = await db.role.create({
      data: {
        name: 'Administrador',
        description: 'Acceso total al sistema',
        level: 100,
        isDefault: true,
        companyId: company.id,
      },
    })

    // Assign all existing permissions to the admin role
    const allPermissions = await db.permission.findMany({
      select: { id: true },
    })

    if (allPermissions.length > 0) {
      await db.rolePermission.createMany({
        data: allPermissions.map((p) => ({
          roleId: adminRole.id,
          permissionId: p.id,
        })),
        skipDuplicates: true,
      })
    }

    // Create user with hashed password and assigned role
    const user = await db.user.create({
      data: {
        email,
        password: hashedPassword,
        name,
        role: 'admin',
        roleId: adminRole.id,
        companyId: company.id,
      },
    })

    // Generate JWT tokens
    const tokenPayload = {
      userId: user.id,
      email: user.email,
      companyId: user.companyId,
      roleId: user.roleId,
      role: user.role,
    }

    const accessToken = await generateAccessToken(tokenPayload)
    const refreshToken = await generateRefreshToken({ userId: user.id })

    return NextResponse.json(
      {
        accessToken,
        refreshToken,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          roleId: user.roleId,
          companyId: user.companyId,
        },
        company: {
          id: company.id,
          name: company.name,
          cuit: company.cuit,
        },
      },
      { status: 201 }
    )
  } catch (error) {
    console.error('Register error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
