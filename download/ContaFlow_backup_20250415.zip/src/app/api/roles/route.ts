import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/roles?companyId=xxx – List all roles for a company with permissions count
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const companyId = searchParams.get('companyId')

    if (!companyId) {
      return NextResponse.json(
        { error: 'companyId is required' },
        { status: 400 }
      )
    }

    const roles = await db.role.findMany({
      where: { companyId },
      include: {
        _count: {
          select: { permissions: true, users: true },
        },
      },
      orderBy: { level: 'desc' },
    })

    return NextResponse.json({ roles })
  } catch (error) {
    console.error('List roles error:', error)
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}

// POST /api/roles – Create a new role
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, description, level, companyId, permissionIds } = body

    if (!name || !companyId) {
      return NextResponse.json(
        { error: 'name and companyId are required' },
        { status: 400 }
      )
    }

    // Check for duplicate role name within the company
    const existing = await db.role.findUnique({
      where: {
        companyId_name: {
          companyId,
          name,
        },
      },
    })

    if (existing) {
      return NextResponse.json(
        { error: 'Ya existe un rol con ese nombre en esta empresa' },
        { status: 409 }
      )
    }

    // Validate permissionIds if provided
    if (permissionIds && permissionIds.length > 0) {
      const permissionsCount = await db.permission.count({
        where: { id: { in: permissionIds } },
      })

      if (permissionsCount !== permissionIds.length) {
        return NextResponse.json(
          { error: 'Uno o más permisos no válidos' },
          { status: 400 }
        )
      }
    }

    // Create the role with permissions in a transaction
    const role = await db.$transaction(async (tx) => {
      const newRole = await tx.role.create({
        data: {
          name,
          description: description || null,
          level: level ?? 0,
          companyId,
        },
      })

      if (permissionIds && permissionIds.length > 0) {
        await tx.rolePermission.createMany({
          data: permissionIds.map((permissionId: string) => ({
            roleId: newRole.id,
            permissionId,
          })),
        })
      }

      return tx.role.findUnique({
        where: { id: newRole.id },
        include: {
          permissions: {
            include: { permission: true },
          },
        },
      })
    })

    return NextResponse.json({ role }, { status: 201 })
  } catch (error) {
    console.error('Create role error:', error)
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}
