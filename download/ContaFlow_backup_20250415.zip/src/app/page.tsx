'use client'

import { useEffect, useState } from 'react'
import { useAppStore } from '@/lib/store'
import { AuthScreen } from '@/components/erp/AuthScreen'
import { ERPLayout } from '@/components/erp/ERPLayout'
import { DashboardView } from '@/components/erp/DashboardView'
import { AccountsView } from '@/components/erp/AccountsView'
import { JournalEntriesView } from '@/components/erp/JournalEntriesView'
import { ClientsView } from '@/components/erp/ClientsView'
import { ProvidersView } from '@/components/erp/ProvidersView'
import { InvoicesView } from '@/components/erp/InvoicesView'
import { PaymentsView } from '@/components/erp/PaymentsView'
import { BankAccountsView } from '@/components/erp/BankAccountsView'
import { ReportsView } from '@/components/erp/ReportsView'
import { AuditLogView } from '@/components/erp/AuditLogView'
import { UsersView } from '@/components/erp/UsersView'
import { SettingsView } from '@/components/erp/SettingsView'
import { RolesView } from '@/components/erp/RolesView'

export default function Home() {
  const isAuthenticated = useAppStore((s) => s.isAuthenticated)
  const currentView = useAppStore((s) => s.currentView)
  const hydrateFromStorage = useAppStore((s) => s.hydrateFromStorage)
  const _hasHydrated = useAppStore((s) => s._hasHydrated)
  const [hasMounted, setHasMounted] = useState(false)

  // Hydrate auth state from localStorage on client mount only
  useEffect(() => {
    hydrateFromStorage()
    setHasMounted(true)
  }, [hydrateFromStorage])

  // Before client hydration completes, render nothing (matches server)
  if (!hasMounted || !_hasHydrated) {
    return null
  }

  if (!isAuthenticated) {
    return <AuthScreen />
  }

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <DashboardView />
      case 'accounts':
        return <AccountsView />
      case 'journal-entries':
        return <JournalEntriesView />
      case 'clients':
        return <ClientsView />
      case 'providers':
        return <ProvidersView />
      case 'invoices':
        return <InvoicesView />
      case 'payments':
        return <PaymentsView />
      case 'bank-accounts':
        return <BankAccountsView />
      case 'audit-log':
        return <AuditLogView />
      case 'reports':
        return <ReportsView />
      case 'users':
        return <UsersView />
      case 'roles':
        return <RolesView />
      case 'settings':
        return <SettingsView />
      default:
        return <DashboardView />
    }
  }

  return (
    <ERPLayout>
      {renderView()}
    </ERPLayout>
  )
}
