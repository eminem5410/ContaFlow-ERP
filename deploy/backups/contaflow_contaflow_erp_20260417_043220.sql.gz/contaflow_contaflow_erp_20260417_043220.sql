--
-- PostgreSQL database dump
--

\restrict 9ZwJo3m3SwoaqRpVxRJmvCpeBoKHsiNphkrOuEcbMYTYrymgtUf0lvyjJ1TTIMg

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: fn_update_account_balance(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_update_account_balance() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE accounts 
        SET current_balance = current_balance + NEW.debit - NEW.credit,
            updated_at = NOW()
        WHERE id = NEW.account_id;
    ELSIF TG_OP = 'UPDATE' THEN
        UPDATE accounts 
        SET current_balance = current_balance + NEW.debit - NEW.credit - OLD.debit + OLD.credit,
            updated_at = NOW()
        WHERE id = NEW.account_id;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE accounts 
        SET current_balance = current_balance - OLD.debit + OLD.credit,
            updated_at = NOW()
        WHERE id = OLD.account_id;
    END IF;
    RETURN NULL;
END;
$$;


--
-- Name: fn_validate_double_entry(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_validate_double_entry() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    total_debit DECIMAL(18,2);
    total_credit DECIMAL(18,2);
BEGIN
    IF NEW.status = 'posted' AND OLD.status IS DISTINCT FROM 'posted' THEN
        SELECT COALESCE(SUM(debit),0), COALESCE(SUM(credit),0)
        INTO total_debit, total_credit
        FROM journal_lines WHERE entry_id = NEW.id;
        
        IF ABS(total_debit - total_credit) > 0.01 THEN
            RAISE EXCEPTION 'Partida doble invalida: debitos (%) != creditos (%)', total_debit, total_credit;
        END IF;
        
        -- Actualizar totales del asiento
        NEW.total_debit := total_debit;
        NEW.total_credit := total_credit;
        NEW.posted_at := NOW();
    END IF;
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Account; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Account" (
    id text NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(200) NOT NULL,
    type character varying(50) NOT NULL,
    subtype character varying(50),
    "parentId" text,
    level integer DEFAULT 1 NOT NULL,
    balance double precision DEFAULT 0 NOT NULL,
    "companyId" text NOT NULL
);


--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "userName" character varying(200) NOT NULL,
    action character varying(50) NOT NULL,
    entity character varying(50) NOT NULL,
    "entityId" text,
    details text,
    "companyId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: BankAccount; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BankAccount" (
    id text NOT NULL,
    name character varying(200) NOT NULL,
    bank character varying(100),
    number character varying(50),
    type character varying(50) DEFAULT 'cta_corriente'::character varying NOT NULL,
    balance double precision DEFAULT 0 NOT NULL,
    currency character varying(10) DEFAULT 'ARS'::character varying NOT NULL,
    "companyId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Client; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Client" (
    id text NOT NULL,
    code character varying(20),
    name character varying(200) NOT NULL,
    cuit character varying(20),
    email character varying(255),
    phone character varying(50),
    address character varying(500),
    city character varying(100),
    province character varying(100),
    notes text,
    balance double precision DEFAULT 0 NOT NULL,
    "companyId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Company; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Company" (
    id text NOT NULL,
    name character varying(200) NOT NULL,
    cuit character varying(20),
    email character varying(255),
    phone character varying(50),
    address character varying(500),
    logo character varying(500),
    plan character varying(50) DEFAULT 'basico'::character varying NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Invoice; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Invoice" (
    id text NOT NULL,
    number character varying(50) NOT NULL,
    type character varying(10) NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "dueDate" timestamp(3) without time zone,
    total double precision DEFAULT 0 NOT NULL,
    tax double precision DEFAULT 0 NOT NULL,
    "netTotal" double precision DEFAULT 0 NOT NULL,
    "amountPaid" double precision DEFAULT 0 NOT NULL,
    status character varying(50) DEFAULT 'pendiente'::character varying NOT NULL,
    notes text,
    "clientId" text,
    "companyId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: InvoiceItem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."InvoiceItem" (
    id text NOT NULL,
    description character varying(500) NOT NULL,
    quantity double precision DEFAULT 1 NOT NULL,
    "unitPrice" double precision DEFAULT 0 NOT NULL,
    subtotal double precision DEFAULT 0 NOT NULL,
    "taxRate" double precision DEFAULT 21 NOT NULL,
    "taxAmount" double precision DEFAULT 0 NOT NULL,
    "invoiceId" text NOT NULL
);


--
-- Name: JournalEntry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."JournalEntry" (
    id text NOT NULL,
    number integer NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    description character varying(500) NOT NULL,
    concept character varying(500),
    status character varying(50) DEFAULT 'borrador'::character varying NOT NULL,
    "companyId" text NOT NULL,
    "totalDebit" double precision DEFAULT 0 NOT NULL,
    "totalCredit" double precision DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: JournalEntryLine; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."JournalEntryLine" (
    id text NOT NULL,
    "journalEntryId" text NOT NULL,
    "accountId" text NOT NULL,
    debit double precision DEFAULT 0 NOT NULL,
    credit double precision DEFAULT 0 NOT NULL,
    description text
);


--
-- Name: Payment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Payment" (
    id text NOT NULL,
    number character varying(50) NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    amount double precision NOT NULL,
    method character varying(50) DEFAULT 'transferencia'::character varying NOT NULL,
    reference character varying(100),
    type character varying(20) DEFAULT 'cobro'::character varying NOT NULL,
    notes text,
    "invoiceId" text,
    "clientId" text,
    "providerId" text,
    "bankAccountId" text,
    "companyId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Permission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Permission" (
    id text NOT NULL,
    module character varying(50) NOT NULL,
    action character varying(50) NOT NULL,
    description character varying(200) NOT NULL
);


--
-- Name: PlanPayment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PlanPayment" (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    "companyId" text NOT NULL,
    plan text NOT NULL,
    amount double precision NOT NULL,
    currency text DEFAULT 'ARS'::text,
    status text DEFAULT 'pending'::text,
    "mercadopagoPrefId" text,
    "mercadopagoPaymentId" text,
    "externalReference" text,
    "approvalDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: Provider; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Provider" (
    id text NOT NULL,
    code character varying(20),
    name character varying(200) NOT NULL,
    cuit character varying(20),
    email character varying(255),
    phone character varying(50),
    address character varying(500),
    city character varying(100),
    province character varying(100),
    notes text,
    balance double precision DEFAULT 0 NOT NULL,
    "companyId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Role" (
    id text NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(200),
    "isDefault" boolean DEFAULT false NOT NULL,
    level integer DEFAULT 0 NOT NULL,
    "companyId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: RolePermission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RolePermission" (
    id text NOT NULL,
    "roleId" text NOT NULL,
    "permissionId" text NOT NULL
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(500) NOT NULL,
    name character varying(200) NOT NULL,
    role character varying(50) DEFAULT 'admin'::character varying NOT NULL,
    "roleId" text,
    "companyId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Data for Name: Account; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Account" (id, code, name, type, subtype, "parentId", level, balance, "companyId") FROM stdin;
act_001	1.1.1	Caja	activo	corriente	\N	1	125000	cmo0p45e00000lq01dnyoaj4b
act_002	1.1.2	Banco Nacion Cta. Cte.	activo	corriente	\N	1	1850000	cmo0p45e00000lq01dnyoaj4b
act_003	1.1.3	Banco Provincia Cta. Cte.	activo	corriente	\N	1	980000	cmo0p45e00000lq01dnyoaj4b
act_004	1.2.1	Clientes	activo	corriente	\N	1	620000	cmo0p45e00000lq01dnyoaj4b
act_005	1.2.2	Deudores Varios	activo	corriente	\N	1	0	cmo0p45e00000lq01dnyoaj4b
act_006	1.3.1	Mercaderias	activo	corriente	\N	1	950000	cmo0p45e00000lq01dnyoaj4b
act_007	1.3.2	Materias Primas	activo	corriente	\N	1	380000	cmo0p45e00000lq01dnyoaj4b
act_008	1.4.1	IVA Credito Fiscal	activo	corriente	\N	1	156750	cmo0p45e00000lq01dnyoaj4b
act_009	1.5.1	Muebles y Utiles	activo	no_corriente	\N	1	320000	cmo0p45e00000lq01dnyoaj4b
act_010	1.5.2	Equipos de Computacion	activo	no_corriente	\N	1	480000	cmo0p45e00000lq01dnyoaj4b
act_011	1.5.3	Rodados	activo	no_corriente	\N	1	1500000	cmo0p45e00000lq01dnyoaj4b
act_012	1.6.1	Depreciacion Acumulada Muebles	activo	no_corriente	\N	1	-64000	cmo0p45e00000lq01dnyoaj4b
act_013	1.6.2	Depreciacion Acumulada Equipos	activo	no_corriente	\N	1	-96000	cmo0p45e00000lq01dnyoaj4b
act_014	1.6.3	Depreciacion Acumulada Rodados	activo	no_corriente	\N	1	-300000	cmo0p45e00000lq01dnyoaj4b
pas_001	2.1.1	Proveedores	pasivo	corriente	\N	1	-410000	cmo0p45e00000lq01dnyoaj4b
pas_002	2.1.2	Acreedores Varios	pasivo	corriente	\N	1	0	cmo0p45e00000lq01dnyoaj4b
pas_003	2.1.3	Sueldos a Pagar	pasivo	corriente	\N	1	-285000	cmo0p45e00000lq01dnyoaj4b
pas_004	2.1.4	Cargas Sociales a Pagar	pasivo	corriente	\N	1	-95000	cmo0p45e00000lq01dnyoaj4b
pas_005	2.1.5	IVA Debito Fiscal	pasivo	corriente	\N	1	-189000	cmo0p45e00000lq01dnyoaj4b
pas_006	2.1.6	Impuesto a las Ganancias	pasivo	corriente	\N	1	-65000	cmo0p45e00000lq01dnyoaj4b
pas_007	2.2.1	Prestamos Bancarios	pasivo	no_corriente	\N	1	-800000	cmo0p45e00000lq01dnyoaj4b
pat_001	3.1.1	Capital Social	patrimonio	\N	\N	1	5000000	cmo0p45e00000lq01dnyoaj4b
pat_002	3.2.1	Reserva Legal	patrimonio	\N	\N	1	250000	cmo0p45e00000lq01dnyoaj4b
pat_003	3.3.1	Resultado del Ejercicio	patrimonio	\N	\N	1	2745750	cmo0p45e00000lq01dnyoaj4b
gas_001	5.1.1	Compras de Mercaderias	gasto	\N	\N	1	-1800000	cmo0p45e00000lq01dnyoaj4b
gas_002	5.1.2	Costo Mercaderia Vendida	gasto	\N	\N	1	-1420000	cmo0p45e00000lq01dnyoaj4b
gas_003	5.2.1	Sueldos y Jornales	gasto	\N	\N	1	-850000	cmo0p45e00000lq01dnyoaj4b
gas_004	5.2.2	Cargas Sociales	gasto	\N	\N	1	-285000	cmo0p45e00000lq01dnyoaj4b
gas_005	5.3.1	Alquileres	gasto	\N	\N	1	-180000	cmo0p45e00000lq01dnyoaj4b
gas_006	5.3.2	Servicios Publicos	gasto	\N	\N	1	-45000	cmo0p45e00000lq01dnyoaj4b
gas_007	5.3.3	Seguros	gasto	\N	\N	1	-36000	cmo0p45e00000lq01dnyoaj4b
gas_008	5.4.1	Depreciacion Muebles	gasto	\N	\N	1	-64000	cmo0p45e00000lq01dnyoaj4b
gas_009	5.4.2	Depreciacion Equipos	gasto	\N	\N	1	-96000	cmo0p45e00000lq01dnyoaj4b
gas_010	5.4.3	Depreciacion Rodados	gasto	\N	\N	1	-300000	cmo0p45e00000lq01dnyoaj4b
gas_011	5.5.1	Gastos Bancarios	gasto	\N	\N	1	-12000	cmo0p45e00000lq01dnyoaj4b
gas_012	5.5.2	Gastos Varios	gasto	\N	\N	1	-28000	cmo0p45e00000lq01dnyoaj4b
ing_001	4.1.1	Ventas de Mercaderias	ingreso	\N	\N	1	4520000	cmo0p45e00000lq01dnyoaj4b
ing_002	4.2.1	Servicios de Consultoria	ingreso	\N	\N	1	850000	cmo0p45e00000lq01dnyoaj4b
ing_003	4.3.1	Intereses Ganados	ingreso	\N	\N	1	35000	cmo0p45e00000lq01dnyoaj4b
ing_004	4.3.2	Descuentos Obtenidos	ingreso	\N	\N	1	8750	cmo0p45e00000lq01dnyoaj4b
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AuditLog" (id, "userId", "userName", action, entity, "entityId", details, "companyId", "createdAt") FROM stdin;
aud_001	user-admin-01	Administrador Demo	login	Auth	\N	Inicio de sesion exitoso	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:23:51.222
aud_002	user-admin-01	Administrador Demo	create	Invoice	inv_001	Factura A FEA-0001 creada	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:23:51.222
aud_003	user-admin-01	Administrador Demo	create	Invoice	inv_002	Factura B FEB-0002 creada	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:23:51.222
aud_004	user-admin-01	Administrador Demo	create	Payment	pag_001	Cobro REC-001 recibido	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:23:51.222
aud_005	user-admin-01	Administrador Demo	create	JournalEntry	aje_002	Asiento Nro 2	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:23:51.222
aud_006	user-admin-01	Administrador Demo	create	JournalEntry	aje_003	Asiento Nro 3	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:23:51.222
aud_007	user-admin-01	Administrador Demo	create	JournalEntry	aje_004	Asiento Nro 4	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:23:51.222
aud_008	user-admin-01	Administrador Demo	create	JournalEntry	aje_005	Asiento Nro 5	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:23:51.222
aud_009	user-admin-01	Administrador Demo	create	Payment	pag_004	Pago Distribuidora	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:23:51.222
aud_010	user-admin-01	Administrador Demo	create	JournalEntry	aje_006	Asiento Nro 6	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:23:51.222
\.


--
-- Data for Name: BankAccount; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."BankAccount" (id, name, bank, number, type, balance, currency, "companyId", "createdAt", "updatedAt") FROM stdin;
ban_001	Banco Nacion	Banco Nacion Argentina	00000345-6	cta_corriente	1850000	ARS	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:22:27.989	2026-04-17 00:22:27.989
ban_002	Banco Provincia	Banco de la Provincia de Buenos Aires	00000789-0	cta_corriente	980000	ARS	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:22:27.989	2026-04-17 00:22:27.989
\.


--
-- Data for Name: Client; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Client" (id, code, name, cuit, email, phone, address, city, province, notes, balance, "companyId", "createdAt", "updatedAt") FROM stdin;
cli_001	CLI-001	Garcia y Asociados S.A.	30-71234567-8	contacto@garciasa.com.ar	011-4567-8901	Av. Corrientes 1234, Piso 8	CABA	Buenos Aires	Cliente corporativo desde 2023	350000	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:22:27.939	2026-04-17 00:22:27.939
cli_002	CLI-002	Lopez Comercial S.R.L.	30-82345678-9	info@lopezcomercial.com	011-5555-1234	Av. Rivadavia 5678	CABA	Buenos Aires	Compra mensual de mercaderia	120000	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:22:27.939	2026-04-17 00:22:27.939
cli_003	CLI-003	Martinez Industrias	30-93456789-0	ventas@martinezind.com.ar	0351-444-5566	Bv. Illia 234, Parque Industrial	Cordoba	Cordoba	Cliente del interior	0	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:22:27.939	2026-04-17 00:22:27.939
cli_004	CLI-004	Rodriguez Constructora	20-12345678-1	admin@rodriguezconst.com	0221-433-2211	Calle 12 Nro 567	La Plata	Buenos Aires	Obras en curso	150000	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:22:27.939	2026-04-17 00:22:27.939
cli_005	CLI-005	Fernandez Servicios Profesionales	23-23456789-0	maria@fernandezsp.com	011-6677-8899	Av. Santa Fe 3210, Of. 5	CABA	Buenos Aires	Monotributista - Factura C	0	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:22:27.939	2026-04-17 00:22:27.939
cmo293vlq001kro01kkk77o27	CL001	nuevocliente	20-234235235-2	ciente@emial.com	2345235235	skafnsjnf	jksdnfjnsd	knsdjkfs	\N	0	cmo27comy0000ro01mjxc3sj1	2026-04-17 01:50:15.998	2026-04-17 01:50:15.998
\.


--
-- Data for Name: Company; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Company" (id, name, cuit, email, phone, address, logo, plan, "createdAt", "updatedAt") FROM stdin;
cmo0p45e00000lq01dnyoaj4b	Empresa Demo S.R.L.	30-12345678-9	admin@empresademo.com.ar	+54 11 4567-8900	Av. Corrientes 1234, CABA	\N	starter	2026-04-16 23:54:12.44	2026-04-16 23:54:12.44
cmo27comy0000ro01mjxc3sj1	Garcia y Contadores S.R.L.	30-99999999-9	\N	\N	\N	\N	starter	2026-04-17 01:01:07.643	2026-04-17 01:01:07.643
\.


--
-- Data for Name: Invoice; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Invoice" (id, number, type, date, "dueDate", total, tax, "netTotal", "amountPaid", status, notes, "clientId", "companyId", "createdAt", "updatedAt") FROM stdin;
inv_001	FEA-0001	factura_a	2026-03-15 10:00:00	2026-04-15 00:00:00	363000	63000	300000	363000	pagada	Factura venta mensual Marzo 2026	cli_001	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:22:27.997	2026-04-17 00:22:27.997
inv_002	FEB-0002	factura_b	2026-03-20 14:30:00	2026-04-20 00:00:00	484000	84000	400000	242000	parcial	Venta de mercaderia variada	cli_002	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:22:27.997	2026-04-17 00:22:27.997
inv_003	FEA-0003	factura_a	2026-04-01 09:15:00	2026-05-01 00:00:00	181500	31500	150000	0	pendiente	Materiales para obra Avellaneda	cli_004	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:22:27.997	2026-04-17 00:22:27.997
inv_004	FEC-0001	factura_c	2026-04-05 11:00:00	2026-04-05 00:00:00	85000	0	85000	85000	pagada	Asesoria impositiva abril	cli_005	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:22:27.997	2026-04-17 00:22:27.997
inv_005	FEB-0003	factura_b	2026-04-10 16:45:00	2026-05-10 00:00:00	242000	42000	200000	0	pendiente	Equipos seguridad industrial	cli_003	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:22:27.997	2026-04-17 00:22:27.997
inv_006	FCA-0001	factura_a	2026-03-10 08:00:00	2026-04-10 00:00:00	363000	63000	300000	180000	parcial	Compra mercaderia reventa Marzo	\N	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:22:27.997	2026-04-17 00:22:27.997
inv_007	FCA-0002	factura_a	2026-03-25 11:30:00	2026-04-25 00:00:00	121000	21000	100000	0	pendiente	5 notebooks Lenovo ThinkPad	\N	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:22:27.997	2026-04-17 00:22:27.997
\.


--
-- Data for Name: InvoiceItem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."InvoiceItem" (id, description, quantity, "unitPrice", subtotal, "taxRate", "taxAmount", "invoiceId") FROM stdin;
iti_001a	Servicio de consultoria contable - Marzo	1	200000	200000	21	42000	inv_001
iti_001b	Auditoria trimestral	1	100000	100000	21	21000	inv_001
iti_002a	Repuestos industriales x100	100	2500	250000	21	52500	inv_002
iti_002b	Herramientas mecanicas x50	50	3000	150000	21	31500	inv_002
iti_003a	Cemento Portland x200 bolsas	200	750	150000	21	31500	inv_003
iti_004a	Asesoria impositiva mensual	1	85000	85000	0	0	inv_004
iti_005a	Casco de seguridad x200	200	500	100000	21	21000	inv_005
iti_005b	Guantes de trabajo x500 pares	500	200	100000	21	21000	inv_005
iti_006a	Mercaderia tipo A x500 uds	500	400	200000	21	42000	inv_006
iti_006b	Mercaderia tipo B x250 uds	250	400	100000	21	21000	inv_006
iti_007a	Notebook Lenovo ThinkPad T14	5	20000	100000	21	21000	inv_007
\.


--
-- Data for Name: JournalEntry; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."JournalEntry" (id, number, date, description, concept, status, "companyId", "totalDebit", "totalCredit", "createdAt", "updatedAt") FROM stdin;
aje_001	1	2026-01-01 00:00:00	Asiento de Apertura del Ejercicio 2026	apertura	confirmado	cmo0p45e00000lq01dnyoaj4b	5375000	5375000	2026-04-17 00:22:28.031	2026-04-17 00:22:28.031
aje_002	2	2026-03-15 10:00:00	Factura A FEA-0001 - Garcia y Asociados	venta	confirmado	cmo0p45e00000lq01dnyoaj4b	363000	363000	2026-04-17 00:22:28.031	2026-04-17 00:22:28.031
aje_003	3	2026-03-20 14:00:00	Cobro factura Garcia - Transferencia	cobro	confirmado	cmo0p45e00000lq01dnyoaj4b	363000	363000	2026-04-17 00:22:28.031	2026-04-17 00:22:28.031
aje_004	4	2026-03-20 14:30:00	Factura B FEB-0002 - Lopez Comercial	venta	confirmado	cmo0p45e00000lq01dnyoaj4b	484000	484000	2026-04-17 00:22:28.031	2026-04-17 00:22:28.031
aje_005	5	2026-03-10 08:00:00	Compra FCA-0001 - Distribuidora Nacional	compra	confirmado	cmo0p45e00000lq01dnyoaj4b	363000	363000	2026-04-17 00:22:28.031	2026-04-17 00:22:28.031
aje_006	6	2026-04-01 09:00:00	Pago parcial Distribuidora Nacional	pago	confirmado	cmo0p45e00000lq01dnyoaj4b	180000	180000	2026-04-17 00:22:28.031	2026-04-17 00:22:28.031
aje_007	7	2026-04-01 10:00:00	Cobro parcial Lopez Comercial	cobro	confirmado	cmo0p45e00000lq01dnyoaj4b	242000	242000	2026-04-17 00:22:28.031	2026-04-17 00:22:28.031
aje_008	8	2026-04-01 00:00:00	Pago alquiler oficina Abril 2026	gasto	confirmado	cmo0p45e00000lq01dnyoaj4b	180000	180000	2026-04-17 00:22:28.031	2026-04-17 00:22:28.031
aje_009	9	2026-03-31 00:00:00	Liquidacion sueldos Marzo 2026	sueldos	confirmado	cmo0p45e00000lq01dnyoaj4b	285000	285000	2026-04-17 00:22:28.031	2026-04-17 00:22:28.031
aje_010	10	2026-04-05 11:30:00	Cobro efectivo Fernandez Servicios	cobro	confirmado	cmo0p45e00000lq01dnyoaj4b	85000	85000	2026-04-17 00:22:28.031	2026-04-17 00:22:28.031
\.


--
-- Data for Name: JournalEntryLine; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."JournalEntryLine" (id, "journalEntryId", "accountId", debit, credit, description) FROM stdin;
jal_001a	aje_001	act_001	125000	0	Caja inicial
jal_001b	aje_001	act_002	1850000	0	Saldo Banco Nacion
jal_001c	aje_001	act_003	980000	0	Saldo Banco Provincia
jal_001d	aje_001	act_006	950000	0	Stock mercaderias
jal_001e	aje_001	act_007	380000	0	Materias primas
jal_001f	aje_001	act_009	320000	0	Muebles y utiles
jal_001g	aje_001	act_010	480000	0	Equipos computacion
jal_001h	aje_001	act_011	1500000	0	Rodado vehiculo
jal_001i	aje_001	act_012	0	64000	Deprec acum muebles
jal_001j	aje_001	act_013	0	96000	Deprec acum equipos
jal_001k	aje_001	act_014	0	300000	Deprec acum rodados
jal_001l	aje_001	pas_001	0	410000	Deuda proveedores
jal_001m	aje_001	pas_003	0	285000	Sueldos a pagar
jal_001n	aje_001	pas_004	0	95000	Cargas sociales a pagar
jal_001o	aje_001	pas_007	0	800000	Prestamo bancario
jal_001p	aje_001	pat_001	0	5000000	Capital social
jal_002a	aje_002	act_004	363000	0	Clientes Garcia
jal_002b	aje_002	ing_001	0	300000	Ventas gravadas
jal_002c	aje_002	pas_005	0	63000	IVA debito fiscal
jal_003a	aje_003	act_002	363000	0	Banco Nacion - cobro
jal_003b	aje_003	act_004	0	363000	Clientes Garcia saldado
jal_004a	aje_004	act_004	484000	0	Clientes Lopez
jal_004b	aje_004	ing_001	0	400000	Ventas gravadas
jal_004c	aje_004	pas_005	0	84000	IVA debito fiscal
jal_005a	aje_005	gas_001	300000	0	Compras mercaderias
jal_005b	aje_005	act_008	63000	0	IVA credito fiscal
jal_005c	aje_005	pas_001	0	363000	Proveedores Distribuidora
jal_006a	aje_006	pas_001	180000	0	Proveedores parcial
jal_006b	aje_006	act_003	0	180000	Banco Prov transferencia
jal_007a	aje_007	act_002	242000	0	Banco Nacion cobro
jal_007b	aje_007	act_004	0	242000	Clientes Lopez parcial
jal_008a	aje_008	gas_005	180000	0	Alquiler del mes
jal_008b	aje_008	act_003	0	180000	Banco Prov alquiler
jal_009a	aje_009	gas_003	285000	0	Sueldos personal
jal_009b	aje_009	pas_003	0	285000	Remuneraciones pagar
jal_010a	aje_010	act_001	85000	0	Caja efectivo
jal_010b	aje_010	ing_002	0	85000	Ingresos consultoria
\.


--
-- Data for Name: Payment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Payment" (id, number, date, amount, method, reference, type, notes, "invoiceId", "clientId", "providerId", "bankAccountId", "companyId", "createdAt", "updatedAt") FROM stdin;
pag_001	REC-001	2026-03-20 14:00:00	363000	transferencia	TRF-2026-0001	cobro	Transferencia recibida Garcia	inv_001	cli_001	\N	ban_001	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:22:28.014	2026-04-17 00:22:28.014
pag_002	REC-002	2026-04-01 10:00:00	242000	transferencia	TRF-2026-0002	cobro	Pago parcial Lopez	inv_002	cli_002	\N	ban_001	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:22:28.014	2026-04-17 00:22:28.014
pag_003	REC-003	2026-04-05 11:30:00	85000	efectivo	REC-2026-0003	cobro	Pago efectivo Fernandez	inv_004	cli_005	\N	\N	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:22:28.014	2026-04-17 00:22:28.014
pag_004	PAG-001	2026-04-01 09:00:00	180000	transferencia	TRF-2026-0004	pago	Pago parcial Distribuidora	inv_006	\N	pro_001	ban_002	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:22:28.014	2026-04-17 00:22:28.014
pag_005	PAG-002	2026-04-01 00:00:00	180000	transferencia	TRF-2026-0005	pago	Alquiler oficina Abril	\N	\N	\N	ban_002	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:22:28.014	2026-04-17 00:22:28.014
\.


--
-- Data for Name: Permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Permission" (id, module, action, description) FROM stdin;
perm-accounts-view	accounts	view	Plan de Cuentas - Ver
perm-accounts-create	accounts	create	Plan de Cuentas - Crear
perm-accounts-edit	accounts	edit	Plan de Cuentas - Editar
perm-accounts-delete	accounts	delete	Plan de Cuentas - Eliminar
perm-je-view	journal-entries	view	Asientos - Ver
perm-je-create	journal-entries	create	Asientos - Crear
perm-je-edit	journal-entries	edit	Asientos - Editar
perm-je-delete	journal-entries	delete	Asientos - Eliminar
perm-je-confirm	journal-entries	confirm	Asientos - Confirmar
perm-clients-view	clients	view	Clientes - Ver
perm-clients-create	clients	create	Clientes - Crear
perm-clients-edit	clients	edit	Clientes - Editar
perm-clients-delete	clients	delete	Clientes - Eliminar
perm-providers-view	providers	view	Proveedores - Ver
perm-providers-create	providers	create	Proveedores - Crear
perm-providers-edit	providers	edit	Proveedores - Editar
perm-providers-delete	providers	delete	Proveedores - Eliminar
perm-invoices-view	invoices	view	Facturas - Ver
perm-invoices-create	invoices	create	Facturas - Crear
perm-invoices-edit	invoices	edit	Facturas - Editar
perm-invoices-delete	invoices	delete	Facturas - Eliminar
perm-payments-view	payments	view	Pagos - Ver
perm-payments-create	payments	create	Pagos - Crear
perm-payments-edit	payments	edit	Pagos - Editar
perm-payments-delete	payments	delete	Pagos - Eliminar
perm-bank-view	bank-accounts	view	Bancos - Ver
perm-bank-create	bank-accounts	create	Bancos - Crear
perm-bank-edit	bank-accounts	edit	Bancos - Editar
perm-bank-delete	bank-accounts	delete	Bancos - Eliminar
perm-reports-view	reports	view	Reportes - Ver
perm-reports-create	reports	create	Reportes - Crear
perm-reports-edit	reports	edit	Reportes - Editar
perm-reports-delete	reports	delete	Reportes - Eliminar
perm-reports-export	reports	export	Reportes - Exportar
perm-users-view	users	view	Usuarios - Ver
perm-users-create	users	create	Usuarios - Crear
perm-users-edit	users	edit	Usuarios - Editar
perm-users-delete	users	delete	Usuarios - Eliminar
perm-roles-view	roles	view	Roles - Ver
perm-roles-create	roles	create	Roles - Crear
perm-roles-edit	roles	edit	Roles - Editar
perm-roles-delete	roles	delete	Roles - Eliminar
perm-settings-view	settings	view	Config - Ver
perm-settings-create	settings	create	Config - Crear
perm-settings-edit	settings	edit	Config - Editar
perm-settings-delete	settings	delete	Config - Eliminar
perm-audit-view	audit-log	view	Auditoria - Ver
perm-audit-create	audit-log	create	Auditoria - Crear
perm-audit-edit	audit-log	edit	Auditoria - Editar
perm-audit-delete	audit-log	delete	Auditoria - Eliminar
\.


--
-- Data for Name: PlanPayment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PlanPayment" (id, "companyId", plan, amount, currency, status, "mercadopagoPrefId", "mercadopagoPaymentId", "externalReference", "approvalDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Provider; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Provider" (id, code, name, cuit, email, phone, address, city, province, notes, balance, "companyId", "createdAt", "updatedAt") FROM stdin;
pro_001	PRO-001	Distribuidora Nacional S.A.	30-11112222-3	ventas@distnacional.com	011-4000-1111	Autopista Ricchieri Km 15	Lomas de Zamora	Buenos Aires	Distribuidor mayorista principal	180000	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:22:27.965	2026-04-17 00:22:27.965
pro_002	PRO-002	Tech Solutions S.R.L.	30-22223333-4	soporte@techsolutions.com	011-5000-2222	Av. Independencia 1500	CABA	Buenos Aires	Equipamiento informatico	95000	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:22:27.965	2026-04-17 00:22:27.965
pro_003	PRO-003	Papelera del Sur	30-33334444-5	pedidos@papelerasur.com	0223-488-3300	Calle 50 Nro 890	Mar del Plata	Buenos Aires	Insumos de oficina	45000	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:22:27.965	2026-04-17 00:22:27.965
pro_004	PRO-004	Transportes Ruta S.A.	30-44445555-6	despacho@transportesruta.com	011-6000-4444	Darsena Sur, Puerto Nuevo	CABA	Buenos Aires	Logistica y fletes	90000	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:22:27.965	2026-04-17 00:22:27.965
pro_005	PRO-005	Seguros La Boca Cia.	30-55556666-7	polizas@seguroslaboca.com	011-4361-5500	Av. Pedro de Mendoza 2500	CABA	Buenos Aires	Aseguradora	0	cmo0p45e00000lq01dnyoaj4b	2026-04-17 00:22:27.965	2026-04-17 00:22:27.965
\.


--
-- Data for Name: Role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Role" (id, name, description, "isDefault", level, "companyId", "createdAt", "updatedAt") FROM stdin;
role-admin-01	Administrador	Acceso total al sistema	t	100	cmo0p45e00000lq01dnyoaj4b	2026-04-16 23:54:12.448	2026-04-16 23:54:12.448
role-contador-01	Contador	Gestion contable completa	f	50	cmo0p45e00000lq01dnyoaj4b	2026-04-16 23:54:12.448	2026-04-16 23:54:12.448
role-visualizador-01	Visualizador	Solo lectura	f	10	cmo0p45e00000lq01dnyoaj4b	2026-04-16 23:54:12.448	2026-04-16 23:54:12.448
cmo27conw0002ro01y00yyvdb	Administrador	Acceso total al sistema	t	100	cmo27comy0000ro01mjxc3sj1	2026-04-17 01:01:07.676	2026-04-17 01:01:07.676
\.


--
-- Data for Name: RolePermission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RolePermission" (id, "roleId", "permissionId") FROM stdin;
rp-admin-01	role-admin-01	perm-accounts-view
rp-admin-02	role-admin-01	perm-accounts-create
rp-admin-03	role-admin-01	perm-accounts-edit
rp-admin-04	role-admin-01	perm-accounts-delete
rp-admin-05	role-admin-01	perm-je-view
rp-admin-06	role-admin-01	perm-je-create
rp-admin-07	role-admin-01	perm-je-edit
rp-admin-08	role-admin-01	perm-je-delete
rp-admin-09	role-admin-01	perm-je-confirm
rp-admin-10	role-admin-01	perm-clients-view
rp-admin-11	role-admin-01	perm-clients-create
rp-admin-12	role-admin-01	perm-clients-edit
rp-admin-13	role-admin-01	perm-clients-delete
rp-admin-14	role-admin-01	perm-providers-view
rp-admin-15	role-admin-01	perm-providers-create
rp-admin-16	role-admin-01	perm-providers-edit
rp-admin-17	role-admin-01	perm-providers-delete
rp-admin-18	role-admin-01	perm-invoices-view
rp-admin-19	role-admin-01	perm-invoices-create
rp-admin-20	role-admin-01	perm-invoices-edit
rp-admin-21	role-admin-01	perm-invoices-delete
rp-admin-22	role-admin-01	perm-payments-view
rp-admin-23	role-admin-01	perm-payments-create
rp-admin-24	role-admin-01	perm-payments-edit
rp-admin-25	role-admin-01	perm-payments-delete
rp-admin-26	role-admin-01	perm-bank-view
rp-admin-27	role-admin-01	perm-bank-create
rp-admin-28	role-admin-01	perm-bank-edit
rp-admin-29	role-admin-01	perm-bank-delete
rp-admin-30	role-admin-01	perm-reports-view
rp-admin-31	role-admin-01	perm-reports-create
rp-admin-32	role-admin-01	perm-reports-edit
rp-admin-33	role-admin-01	perm-reports-delete
rp-admin-34	role-admin-01	perm-reports-export
rp-admin-35	role-admin-01	perm-users-view
rp-admin-36	role-admin-01	perm-users-create
rp-admin-37	role-admin-01	perm-users-edit
rp-admin-38	role-admin-01	perm-users-delete
rp-admin-39	role-admin-01	perm-roles-view
rp-admin-40	role-admin-01	perm-roles-create
rp-admin-41	role-admin-01	perm-roles-edit
rp-admin-42	role-admin-01	perm-roles-delete
rp-admin-43	role-admin-01	perm-settings-view
rp-admin-44	role-admin-01	perm-settings-create
rp-admin-45	role-admin-01	perm-settings-edit
rp-admin-46	role-admin-01	perm-settings-delete
rp-admin-47	role-admin-01	perm-audit-view
rp-admin-48	role-admin-01	perm-audit-create
rp-admin-49	role-admin-01	perm-audit-edit
rp-admin-50	role-admin-01	perm-audit-delete
rp-cont-01	role-contador-01	perm-accounts-view
rp-cont-02	role-contador-01	perm-accounts-create
rp-cont-03	role-contador-01	perm-accounts-edit
rp-cont-04	role-contador-01	perm-je-view
rp-cont-05	role-contador-01	perm-je-create
rp-cont-06	role-contador-01	perm-je-edit
rp-cont-07	role-contador-01	perm-je-confirm
rp-cont-08	role-contador-01	perm-clients-view
rp-cont-09	role-contador-01	perm-clients-create
rp-cont-10	role-contador-01	perm-clients-edit
rp-cont-11	role-contador-01	perm-providers-view
rp-cont-12	role-contador-01	perm-providers-create
rp-cont-13	role-contador-01	perm-providers-edit
rp-cont-14	role-contador-01	perm-invoices-view
rp-cont-15	role-contador-01	perm-invoices-create
rp-cont-16	role-contador-01	perm-invoices-edit
rp-cont-17	role-contador-01	perm-payments-view
rp-cont-18	role-contador-01	perm-payments-create
rp-cont-19	role-contador-01	perm-payments-edit
rp-cont-20	role-contador-01	perm-bank-view
rp-cont-21	role-contador-01	perm-bank-create
rp-cont-22	role-contador-01	perm-bank-edit
rp-cont-23	role-contador-01	perm-reports-view
rp-cont-24	role-contador-01	perm-reports-export
rp-view-01	role-visualizador-01	perm-accounts-view
rp-view-02	role-visualizador-01	perm-je-view
rp-view-03	role-visualizador-01	perm-clients-view
rp-view-04	role-visualizador-01	perm-providers-view
rp-view-05	role-visualizador-01	perm-invoices-view
rp-view-06	role-visualizador-01	perm-payments-view
rp-view-07	role-visualizador-01	perm-bank-view
rp-view-08	role-visualizador-01	perm-reports-view
rp-view-09	role-visualizador-01	perm-users-view
rp-view-10	role-visualizador-01	perm-roles-view
rp-view-11	role-visualizador-01	perm-settings-view
rp-view-12	role-visualizador-01	perm-audit-view
cmo27coop0003ro01kb0ukw4t	cmo27conw0002ro01y00yyvdb	perm-accounts-view
cmo27coop0004ro01qf3s9wtw	cmo27conw0002ro01y00yyvdb	perm-accounts-create
cmo27coop0005ro01t5mqpdn7	cmo27conw0002ro01y00yyvdb	perm-accounts-edit
cmo27coop0006ro01xh9nzkk9	cmo27conw0002ro01y00yyvdb	perm-accounts-delete
cmo27coop0007ro01rc0zi3y7	cmo27conw0002ro01y00yyvdb	perm-je-view
cmo27coop0008ro016heh8t1s	cmo27conw0002ro01y00yyvdb	perm-je-create
cmo27coop0009ro016l0qqpcb	cmo27conw0002ro01y00yyvdb	perm-je-edit
cmo27coop000aro017qotwak7	cmo27conw0002ro01y00yyvdb	perm-je-delete
cmo27coop000bro01esd6orgc	cmo27conw0002ro01y00yyvdb	perm-je-confirm
cmo27coop000cro01rasi9l2w	cmo27conw0002ro01y00yyvdb	perm-clients-view
cmo27coop000dro011qe1amcc	cmo27conw0002ro01y00yyvdb	perm-clients-create
cmo27coop000ero013cn7knic	cmo27conw0002ro01y00yyvdb	perm-clients-edit
cmo27coop000fro01p0ja5kfi	cmo27conw0002ro01y00yyvdb	perm-clients-delete
cmo27coop000gro0192y5u9u6	cmo27conw0002ro01y00yyvdb	perm-providers-view
cmo27coop000hro010qid215a	cmo27conw0002ro01y00yyvdb	perm-providers-create
cmo27coop000iro01vdmu8kkj	cmo27conw0002ro01y00yyvdb	perm-providers-edit
cmo27coop000jro01c7ki24wk	cmo27conw0002ro01y00yyvdb	perm-providers-delete
cmo27coop000kro013vzh8v0r	cmo27conw0002ro01y00yyvdb	perm-invoices-view
cmo27coop000lro018nkh90u4	cmo27conw0002ro01y00yyvdb	perm-invoices-create
cmo27coop000mro01wkrw6h7v	cmo27conw0002ro01y00yyvdb	perm-invoices-edit
cmo27coop000nro01bk573y21	cmo27conw0002ro01y00yyvdb	perm-invoices-delete
cmo27coop000oro01heuke9i8	cmo27conw0002ro01y00yyvdb	perm-payments-view
cmo27coop000pro01avklt7br	cmo27conw0002ro01y00yyvdb	perm-payments-create
cmo27coop000qro01cwbxqiel	cmo27conw0002ro01y00yyvdb	perm-payments-edit
cmo27coop000rro015zr4gags	cmo27conw0002ro01y00yyvdb	perm-payments-delete
cmo27coop000sro013usboqem	cmo27conw0002ro01y00yyvdb	perm-bank-view
cmo27coop000tro01i1lzydbb	cmo27conw0002ro01y00yyvdb	perm-bank-create
cmo27coop000uro019tj09cv8	cmo27conw0002ro01y00yyvdb	perm-bank-edit
cmo27coop000vro01lhtqxt0i	cmo27conw0002ro01y00yyvdb	perm-bank-delete
cmo27coop000wro01ij3771lv	cmo27conw0002ro01y00yyvdb	perm-reports-view
cmo27coop000xro014zl2xdja	cmo27conw0002ro01y00yyvdb	perm-reports-create
cmo27coop000yro018pvjybqr	cmo27conw0002ro01y00yyvdb	perm-reports-edit
cmo27coop000zro01ojw9yorw	cmo27conw0002ro01y00yyvdb	perm-reports-delete
cmo27coop0010ro015obg995d	cmo27conw0002ro01y00yyvdb	perm-reports-export
cmo27coop0011ro01jfr4pfaa	cmo27conw0002ro01y00yyvdb	perm-users-view
cmo27coop0012ro01r3kvwj3l	cmo27conw0002ro01y00yyvdb	perm-users-create
cmo27coop0013ro01i54gsvcc	cmo27conw0002ro01y00yyvdb	perm-users-edit
cmo27coop0014ro01w4q9ebmh	cmo27conw0002ro01y00yyvdb	perm-users-delete
cmo27coop0015ro01txxls1e5	cmo27conw0002ro01y00yyvdb	perm-roles-view
cmo27coop0016ro01cfn18k07	cmo27conw0002ro01y00yyvdb	perm-roles-create
cmo27coop0017ro01n9o0ab48	cmo27conw0002ro01y00yyvdb	perm-roles-edit
cmo27coop0018ro01r0lis9dp	cmo27conw0002ro01y00yyvdb	perm-roles-delete
cmo27coop0019ro01pxs5kaj9	cmo27conw0002ro01y00yyvdb	perm-settings-view
cmo27coop001aro014kfonffb	cmo27conw0002ro01y00yyvdb	perm-settings-create
cmo27coop001bro01l5rvna75	cmo27conw0002ro01y00yyvdb	perm-settings-edit
cmo27coop001cro01z29vksmv	cmo27conw0002ro01y00yyvdb	perm-settings-delete
cmo27coop001dro01btzq2lbw	cmo27conw0002ro01y00yyvdb	perm-audit-view
cmo27coop001ero01gyajipy0	cmo27conw0002ro01y00yyvdb	perm-audit-create
cmo27coop001fro01yzv9d6yp	cmo27conw0002ro01y00yyvdb	perm-audit-edit
cmo27coop001gro01cgqkynxd	cmo27conw0002ro01y00yyvdb	perm-audit-delete
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, email, password, name, role, "roleId", "companyId", "createdAt", "updatedAt") FROM stdin;
user-admin-01	admin@empresademo.com.ar	$2b$10$4NlZiH3v3CXqynlW.wpBy.98TSIKF/KlqAfEfITXs.BAlU2GAqmCe	Administrador Demo	admin	role-admin-01	cmo0p45e00000lq01dnyoaj4b	2026-04-16 23:54:12.456	2026-04-16 23:54:12.456
user-contador-01	contador@empresademo.com.ar	$2b$10$QZy/E9E1YtbIBviVo0FtWOGbD23F6bBXoN.rSmy77GqF.YLlZd6ha	Juan Contador	contador	role-contador-01	cmo0p45e00000lq01dnyoaj4b	2026-04-16 23:54:12.456	2026-04-16 23:54:12.456
user-viewer-01	viewer@empresademo.com.ar	$2b$10$glRuzVQmXVkF2hBylUnDWuhwTm6Xdn/2H.MS/eWVgzRQLRP97bMtK	Maria Visualizadora	visualizador	role-visualizador-01	cmo0p45e00000lq01dnyoaj4b	2026-04-16 23:54:12.456	2026-04-16 23:54:12.456
cmo27cord001iro01yiq963g6	carlos@garcia.com	$2b$10$a9NV05tvhTFTPXU/GTxjDOX2Qx.q5cFtZNrSWHCuKfJ1tZXtohNiC	Carlos Garcia	admin	cmo27conw0002ro01y00yyvdb	cmo27comy0000ro01mjxc3sj1	2026-04-17 01:01:07.802	2026-04-17 01:01:07.802
\.


--
-- Name: Account Account_companyId_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_companyId_code_key" UNIQUE ("companyId", code);


--
-- Name: Account Account_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: BankAccount BankAccount_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BankAccount"
    ADD CONSTRAINT "BankAccount_pkey" PRIMARY KEY (id);


--
-- Name: Client Client_cuit_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Client"
    ADD CONSTRAINT "Client_cuit_key" UNIQUE (cuit);


--
-- Name: Client Client_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Client"
    ADD CONSTRAINT "Client_pkey" PRIMARY KEY (id);


--
-- Name: Company Company_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Company"
    ADD CONSTRAINT "Company_pkey" PRIMARY KEY (id);


--
-- Name: InvoiceItem InvoiceItem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InvoiceItem"
    ADD CONSTRAINT "InvoiceItem_pkey" PRIMARY KEY (id);


--
-- Name: Invoice Invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_pkey" PRIMARY KEY (id);


--
-- Name: JournalEntryLine JournalEntryLine_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JournalEntryLine"
    ADD CONSTRAINT "JournalEntryLine_pkey" PRIMARY KEY (id);


--
-- Name: JournalEntry JournalEntry_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JournalEntry"
    ADD CONSTRAINT "JournalEntry_pkey" PRIMARY KEY (id);


--
-- Name: Payment Payment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_pkey" PRIMARY KEY (id);


--
-- Name: Permission Permission_module_action_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Permission"
    ADD CONSTRAINT "Permission_module_action_key" UNIQUE (module, action);


--
-- Name: Permission Permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Permission"
    ADD CONSTRAINT "Permission_pkey" PRIMARY KEY (id);


--
-- Name: PlanPayment PlanPayment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PlanPayment"
    ADD CONSTRAINT "PlanPayment_pkey" PRIMARY KEY (id);


--
-- Name: Provider Provider_cuit_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Provider"
    ADD CONSTRAINT "Provider_cuit_key" UNIQUE (cuit);


--
-- Name: Provider Provider_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Provider"
    ADD CONSTRAINT "Provider_pkey" PRIMARY KEY (id);


--
-- Name: RolePermission RolePermission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RolePermission"
    ADD CONSTRAINT "RolePermission_pkey" PRIMARY KEY (id);


--
-- Name: RolePermission RolePermission_roleId_permissionId_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RolePermission"
    ADD CONSTRAINT "RolePermission_roleId_permissionId_key" UNIQUE ("roleId", "permissionId");


--
-- Name: Role Role_companyId_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Role"
    ADD CONSTRAINT "Role_companyId_name_key" UNIQUE ("companyId", name);


--
-- Name: Role Role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Role"
    ADD CONSTRAINT "Role_pkey" PRIMARY KEY (id);


--
-- Name: User User_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_email_key" UNIQUE (email);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog_companyId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditLog_companyId_idx" ON public."AuditLog" USING btree ("companyId");


--
-- Name: AuditLog_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditLog_createdAt_idx" ON public."AuditLog" USING btree ("createdAt");


--
-- Name: AuditLog_entity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditLog_entity_idx" ON public."AuditLog" USING btree (entity);


--
-- Name: Account Account_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Company"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Account Account_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."Account"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AuditLog AuditLog_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Company"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: BankAccount BankAccount_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BankAccount"
    ADD CONSTRAINT "BankAccount_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Company"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Client Client_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Client"
    ADD CONSTRAINT "Client_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Company"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: InvoiceItem InvoiceItem_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InvoiceItem"
    ADD CONSTRAINT "InvoiceItem_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public."Invoice"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Invoice Invoice_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."Client"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Invoice Invoice_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Company"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: JournalEntryLine JournalEntryLine_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JournalEntryLine"
    ADD CONSTRAINT "JournalEntryLine_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public."Account"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: JournalEntryLine JournalEntryLine_journalEntryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JournalEntryLine"
    ADD CONSTRAINT "JournalEntryLine_journalEntryId_fkey" FOREIGN KEY ("journalEntryId") REFERENCES public."JournalEntry"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: JournalEntry JournalEntry_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JournalEntry"
    ADD CONSTRAINT "JournalEntry_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Company"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Payment Payment_bankAccountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_bankAccountId_fkey" FOREIGN KEY ("bankAccountId") REFERENCES public."BankAccount"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Payment Payment_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public."Client"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Payment Payment_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Company"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Payment Payment_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public."Invoice"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Payment Payment_providerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_providerId_fkey" FOREIGN KEY ("providerId") REFERENCES public."Provider"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Provider Provider_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Provider"
    ADD CONSTRAINT "Provider_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Company"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: RolePermission RolePermission_permissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RolePermission"
    ADD CONSTRAINT "RolePermission_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES public."Permission"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: RolePermission RolePermission_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RolePermission"
    ADD CONSTRAINT "RolePermission_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Role Role_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Role"
    ADD CONSTRAINT "Role_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Company"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: User User_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public."Company"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: User User_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict 9ZwJo3m3SwoaqRpVxRJmvCpeBoKHsiNphkrOuEcbMYTYrymgtUf0lvyjJ1TTIMg

